drop table if exists Bid;
drop table if exists Category;
drop table if exists Item;
drop table if exists Seller;
drop table if exists User;