load data local infile 'user.csv' into table User fields terminated by ' || ';

load data local infile 'seller.csv' into table Seller fields terminated by ' || ';

load data local infile 'item.csv' into table Item fields terminated by ' || ';

load data local infile 'cate.csv' into table Category fields terminated by ' || ';

load data local infile 'bid.csv' into table Bid fields terminated by ' || ';
