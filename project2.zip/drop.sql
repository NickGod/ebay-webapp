drop table Bid;
drop table Category;
drop table Item;
drop table Seller;
drop table User;